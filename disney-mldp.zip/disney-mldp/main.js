(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./pages/platform/platform.module": [
		"./src/app/pages/platform/platform.module.ts",
		"pages-platform-platform-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var module = __webpack_require__(ids[0]);
		return module;
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/api/api.ts":
/*!****************************!*\
  !*** ./src/app/api/api.ts ***!
  \****************************/
/*! exports provided: Api */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Api", function() { return Api; });
var Api = /** @class */ (function () {
    function Api() {
    }
    Api.LOGIN = '/login';
    Api.GET_USER_CLUSTERS = '/getUserClusters';
    Api.CREATE_CLUSTER = '/createCluster';
    Api.START_CLUSTER = '/startCluster';
    Api.STOP_CLUSTER = '/stopCluster';
    Api.DELETE_CLUSTER = '/deleteCluster';
    Api.GET_ALL_CLUSTERS = '/getAllCluster';
    Api.GET_ALL_USERS = '/getAllUsers';
    Api.CREATE_USER = '/createUser';
    Api.DELETE_USER = '/deleteUser';
    Api.GET_LOGS = '/getLogs';
    Api.GET_CLUSTER_LOGS = '/getClusterLogs';
    Api.GIVE_FEEDBACK = '/giveFeedback';
    Api.GET_JSON = '/getUIData';
    Api.GET_CREATE_USER_JSON = '/getUIUserData';
    Api.P0ST_SCHEDULED_TIME = '/scheduleTime';
    return Api;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<router-outlet></router-outlet>\n<app-about></app-about>\n<internet-check *ngIf=\"showtoast\" [hasConnection]=\"hasConnection\" (closeToast)=\"hideToast($event)\"></internet-check>"

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.service */ "./src/app/app.service.ts");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/fesm5/service-worker.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};



var AppComponent = /** @class */ (function () {
    function AppComponent(appService, updates) {
        var _this = this;
        this.appService = appService;
        this.updates = updates;
        this.showtoast = false;
        this.hasConnection = true;
        updates.available.subscribe(function (event) {
            updates.activateUpdate().then(function () {
                document.location.reload(true);
            });
        });
        // updates.checkForUpdate();
        this.appService.isConnected.subscribe(function (isConnected) {
            if (isConnected != null) {
                _this.hasConnection = isConnected;
                _this.showtoast = true;
                if (_this.hasConnection) {
                    setTimeout(function () {
                        _this.showtoast = false;
                    }, 4000);
                }
            }
        });
    }
    AppComponent.prototype.hideToast = function (data) {
        this.showtoast = false;
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")],
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"], _angular_service_worker__WEBPACK_IMPORTED_MODULE_2__["SwUpdate"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.guard.ts":
/*!******************************!*\
  !*** ./src/app/app.guard.ts ***!
  \******************************/
/*! exports provided: AppGuardService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppGuardService", function() { return AppGuardService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngx_pwa_local_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ngx-pwa/local-storage */ "./node_modules/@ngx-pwa/local-storage/fesm5/ngx-pwa-local-storage.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.service */ "./src/app/app.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var AppGuardService = /** @class */ (function () {
    function AppGuardService(appService, router, localStorage) {
        this.appService = appService;
        this.router = router;
        this.localStorage = localStorage;
    }
    AppGuardService.prototype.canActivate = function (routeSnapShot) {
        return this.checkRoute(routeSnapShot);
    };
    AppGuardService.prototype.checkRoute = function (routeSnapShot) {
        var _this = this;
        return new Promise(function (resolve) {
            if (routeSnapShot && routeSnapShot.url && routeSnapShot.url && routeSnapShot.url.length > 0) {
                switch (routeSnapShot.url[0].path) {
                    case 'app':
                        _this.localStorage.getItem('lmuser').subscribe(function (user) {
                            if (user && user.id) {
                                _this.appService.setUser(user.id, user.name, user.role);
                                return resolve(true);
                            }
                            else {
                                if (_this.appService.getUser()) {
                                    return resolve(true);
                                }
                                else {
                                    _this.router.navigate(['login']);
                                    return resolve(false);
                                }
                            }
                        });
                        break;
                    case 'login':
                        _this.localStorage.getItem('lmuser').subscribe(function (user) {
                            if (user && user.id) {
                                _this.appService.setUser(user.id, user.name, user.role);
                                _this.router.navigate(['app']);
                                return resolve(false);
                            }
                            else {
                                return resolve(true);
                            }
                        });
                        break;
                    default:
                        break;
                }
            }
        });
    };
    AppGuardService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])(),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_3__["AppService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], _ngx_pwa_local_storage__WEBPACK_IMPORTED_MODULE_2__["LocalStorage"]])
    ], AppGuardService);
    return AppGuardService;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _pages_login_login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/login/login.page */ "./src/app/pages/login/login.page.ts");
/* harmony import */ var _app_routes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app.routes */ "./src/app/app.routes.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var angular_particle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! angular-particle */ "./node_modules/angular-particle/index.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app.service */ "./src/app/app.service.ts");
/* harmony import */ var _pages_shared_about_about_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pages/shared/about/about.component */ "./src/app/pages/shared/about/about.component.ts");
/* harmony import */ var _app_guard__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./app.guard */ "./src/app/app.guard.ts");
/* harmony import */ var _angular_service_worker__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/service-worker */ "./node_modules/@angular/service-worker/fesm5/service-worker.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _pages_shared_internet_check_internet_check_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./pages/shared/internet-check/internet-check.component */ "./src/app/pages/shared/internet-check/internet-check.component.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
















var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_2__["AppComponent"],
                _pages_login_login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"],
                _pages_shared_about_about_component__WEBPACK_IMPORTED_MODULE_10__["AboutComponent"],
                _pages_shared_internet_check_internet_check_component__WEBPACK_IMPORTED_MODULE_14__["InternetCheckComponent"]
            ],
            imports: [
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_5__["BrowserAnimationsModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                // CommonModule,
                _angular_forms__WEBPACK_IMPORTED_MODULE_6__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClientModule"],
                _app_routes__WEBPACK_IMPORTED_MODULE_4__["AppRouterModule"],
                angular_particle__WEBPACK_IMPORTED_MODULE_8__["ParticlesModule"],
                _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatCardModule"], _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatSelectModule"], _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatIconModule"], _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatFormFieldModule"], _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatInputModule"], _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatButtonModule"], _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatCheckboxModule"], _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatSnackBarModule"], _angular_material__WEBPACK_IMPORTED_MODULE_7__["MatProgressBarModule"],
                _angular_service_worker__WEBPACK_IMPORTED_MODULE_12__["ServiceWorkerModule"].register('ngsw-worker.js', { enabled: _environments_environment__WEBPACK_IMPORTED_MODULE_13__["environment"].production })
            ],
            exports: [_pages_shared_about_about_component__WEBPACK_IMPORTED_MODULE_10__["AboutComponent"]],
            providers: [_app_service__WEBPACK_IMPORTED_MODULE_9__["AppService"], _app_guard__WEBPACK_IMPORTED_MODULE_11__["AppGuardService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/app.routes.ts":
/*!*******************************!*\
  !*** ./src/app/app.routes.ts ***!
  \*******************************/
/*! exports provided: AppRouterModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRouterModule", function() { return AppRouterModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _pages_login_login_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./pages/login/login.page */ "./src/app/pages/login/login.page.ts");
/* harmony import */ var _app_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.guard */ "./src/app/app.guard.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};




//import { PlatformModule } from './pages/platform/platform.module';
var routes = [
    { path: 'login', component: _pages_login_login_page__WEBPACK_IMPORTED_MODULE_2__["LoginPage"], canActivate: [_app_guard__WEBPACK_IMPORTED_MODULE_3__["AppGuardService"]] },
    { path: 'app', loadChildren: './pages/platform/platform.module#PlatformModule', canActivate: [_app_guard__WEBPACK_IMPORTED_MODULE_3__["AppGuardService"]] },
    { path: '', redirectTo: 'login', pathMatch: 'full' },
    { path: '**', redirectTo: 'login', pathMatch: 'full' }
];
var AppRouterModule = /** @class */ (function () {
    function AppRouterModule() {
    }
    AppRouterModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRouterModule);
    return AppRouterModule;
}());



/***/ }),

/***/ "./src/app/app.service.ts":
/*!********************************!*\
  !*** ./src/app/app.service.ts ***!
  \********************************/
/*! exports provided: AppService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppService", function() { return AppService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");
/* harmony import */ var ng_connection_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng-connection-service */ "./node_modules/ng-connection-service/fesm5/ng-connection-service.js");
/* harmony import */ var _models_user__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./models/user */ "./src/app/models/user.ts");
/* harmony import */ var _angular_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/material */ "./node_modules/@angular/material/esm5/material.es5.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _api_api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./api/api */ "./src/app/api/api.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};








var AppService = /** @class */ (function () {
    function AppService(snackBar, connectionService, http) {
        var _this = this;
        this.snackBar = snackBar;
        this.connectionService = connectionService;
        this.http = http;
        this.baseUrl = _environments_environment__WEBPACK_IMPORTED_MODULE_7__["environment"].baseUrl;
        this.isConnected = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
        this.aboutAppBehavior = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](false);
        this.myStyle = {};
        this.myParams = {};
        this.width = 100;
        this.height = 100;
        // getting
        this.UUIDValue = {
            n0348668: "h3ZeQuoM",
            n0349979: "98nxcD9u",
            admin: "wbzkrIba"
        };
        this.connectionService.monitor().subscribe(function (isConnected) {
            _this.isConnected.next(isConnected);
        });
        this.initParticleJS();
    }
    AppService.prototype.setUser = function (id, name, role) {
        this.user = new _models_user__WEBPACK_IMPORTED_MODULE_3__["User"](id, name, role);
    };
    AppService.prototype.getUser = function () {
        return this.user;
    };
    AppService.prototype.initParticleJS = function () {
        this.myStyle = {
            'position': 'fixed',
            'width': '100%',
            'height': '100%',
            'top': 0,
            'left': 0,
            'right': 0,
            'bottom': 0,
            'pointer-events': 'none'
        };
        this.myParams = {
            particles: {
                number: {
                    value: 100,
                    density: {
                        enable: true,
                        value_area: 800
                    }
                },
                color: {
                    value: "#ffffff"
                },
                shape: {
                    type: "circle",
                    stroke: {
                        width: 0,
                        color: "#ffffff"
                    },
                },
                opacity: {
                    value: 1,
                    random: true,
                    anim: {
                        enable: false,
                        speed: 1,
                        opacity_min: 0.1,
                        sync: false
                    }
                },
                size: {
                    value: 1.5,
                    random: true,
                    anim: {
                        enable: false,
                        speed: 20,
                        size_min: 0.1,
                        sync: false
                    }
                },
                line_linked: {
                    enable: true,
                    distance: 150,
                    color: "#c1c1c1",
                    opacity: 0.2,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 1,
                    direction: "none",
                    random: false,
                    straight: false,
                    out_mode: "out",
                    bounce: false,
                    attract: {
                        enable: false,
                        rotateX: 600,
                        rotateY: 1200
                    }
                }
            }
        };
    };
    AppService.prototype.openSnackBar = function (message, action, type, position, duration) {
        var classname = !type ? 'accent-snackbar' : 'primary-snackbar';
        if (position == 'left') {
            this.snackBar.open(message, action, {
                duration: 30000,
                panelClass: [classname],
                horizontalPosition: "left",
                verticalPosition: "bottom"
            });
        }
        else if (position == 'right' || !position) {
            this.snackBar.open(message, action, {
                duration: 3000,
                panelClass: [classname],
                horizontalPosition: "right",
                verticalPosition: "bottom"
            });
        }
    };
    AppService.prototype.login = function (username, password) {
        //let headers = new HttpHeaders({ 'Content-Type': 'application/json' });
        var options = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpHeaders"]({
                'Content-Type': 'application/json'
            })
        };
        var body = new _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpParams"]();
        body = body.set('username', username);
        body = body.set('password', password);
        var data = { 'username': username, 'password': password };
        return this.http.post("" + (this.baseUrl + _api_api__WEBPACK_IMPORTED_MODULE_6__["Api"].LOGIN), data, options);
    };
    AppService.prototype.returnUUID = function (userid) {
        if (this.UUIDValue[userid] !== undefined) {
            console.log("check for the UUID for user " + this.UUIDValue[userid]);
            return this.UUIDValue[userid];
        }
        else {
            console.log("check for the UUID for user is undefined");
            return null;
        }
    };
    AppService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])({
            providedIn: 'root'
        }),
        __metadata("design:paramtypes", [_angular_material__WEBPACK_IMPORTED_MODULE_4__["MatSnackBar"], ng_connection_service__WEBPACK_IMPORTED_MODULE_2__["ConnectionService"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClient"]])
    ], AppService);
    return AppService;
}());



/***/ }),

/***/ "./src/app/models/user.ts":
/*!********************************!*\
  !*** ./src/app/models/user.ts ***!
  \********************************/
/*! exports provided: User */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "User", function() { return User; });
var User = /** @class */ (function () {
    function User(id, name, role) {
        this.id = id;
        this.name = name;
        this.role = role;
    }
    return User;
}());



/***/ }),

/***/ "./src/app/pages/login/login.page.html":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div id=\"home_page\">\n  <section>\n    <section class=\"intro\">\n      <a class=\"logo\" href=\"https://www.libertymutual.com/\" target=\"_blank\"></a>\n      <div class=\"mat-display-2\">TARDIS</div>\n      <div class=\"mat-display-1\">Self-service machine learning development platform</div>\n      <button mat-raised-button (click)=\"knowMore()\">Know more...</button>\n    </section>\n    <section class=\"login\">\n      <mat-card>\n        <mat-progress-bar *ngIf=\"isLoggingIn\" color=\"primary\" mode=\"indeterminate\">\n        </mat-progress-bar>\n        <section class=\"header\">\n          <mat-icon color=\"primary\" color=\"accent\">person_pin</mat-icon>\n        </section>\n        <section class=\"body\">\n          <form class=\"example-form\">\n            <mat-form-field class=\"example-full-width\">\n              <input name=\"username\" type=\"text\" matInput color=\"accent\" placeholder=\"Username\" [(ngModel)]=\"username\"\n                (keyup.enter)=\"login()\" autocomplete=\"off\" />\n              <!-- <mat-error>You must enter a value</mat-error> -->\n            </mat-form-field>\n\n            <mat-form-field class=\"example-full-width\">\n              <input name=\"password\" type=\"password\" color=\"accent\" matInput placeholder=\"Password\"\n                [(ngModel)]=\"password\" (keyup.enter)=\"login()\" autocomplete=\"off\" />\n                <!-- <mat-error>You must enter a value</mat-error> -->\n            </mat-form-field>\n            <mat-checkbox name=\"remember\" color=\"accent\">Remember Me</mat-checkbox>\n          </form>\n\n        </section>\n        <section class=\"footer\">\n            <!-- <mat-error *ngIf=\"credentialsError\">Invalid Credentials</mat-error> -->\n          <button mat-raised-button color=\"accent\" (click)=\"login()\">Login</button>\n        </section>\n      </mat-card>\n    </section>\n  </section>\n  <section class=\"mat-caption\">\n    &copy; This app is for use by authorised Liberty Mutual users only.\n  </section>\n</div>\n<particles [style]=\"myStyle\" [width]=\"width\" [height]=\"height\" [params]=\"myParams\"></particles>\n"

/***/ }),

/***/ "./src/app/pages/login/login.page.scss":
/*!*********************************************!*\
  !*** ./src/app/pages/login/login.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#home_page {\n  height: 100%;\n  width: 100%;\n  background: linear-gradient(#3b4550, #3b4550, #3b4550, #3b4550, #3b4550, #3b4550, #3b4550, #444e59, #505a66, #65707c); }\n  #home_page > section:first-child {\n    height: calc(100% - 40px);\n    width: 100%;\n    display: flex;\n    flex-direction: row;\n    flex-wrap: wrap; }\n  @media only screen and (max-width: 1024px) {\n      #home_page > section:first-child {\n        flex-direction: column;\n        flex-wrap: nowrap;\n        justify-content: space-between; } }\n  #home_page > section:first-child > section {\n      height: 100%;\n      width: 55%; }\n  @media only screen and (max-width: 1024px) {\n        #home_page > section:first-child > section {\n          height: auto;\n          width: 100%; } }\n  #home_page > section:first-child > section.login {\n        width: 45%;\n        display: flex;\n        justify-content: center;\n        align-items: center; }\n  #home_page > section:first-child > section.login > mat-card {\n          width: 55%;\n          position: relative;\n          height: 60%;\n          min-height: 250px;\n          background: #3b4550;\n          background: #363d4459;\n          z-index: 9999;\n          display: flex;\n          flex-direction: column;\n          justify-content: space-between; }\n  @media only screen and (max-width: 1024px) {\n            #home_page > section:first-child > section.login > mat-card {\n              width: 65%; } }\n  #home_page > section:first-child > section.login > mat-card .mat-progress-bar {\n            position: absolute;\n            top: 0;\n            left: 0;\n            width: 100%;\n            height: 3px; }\n  #home_page > section:first-child > section.login > mat-card > section {\n            display: flex;\n            width: 100%;\n            flex-direction: column;\n            justify-content: center;\n            align-items: center; }\n  #home_page > section:first-child > section.login > mat-card > section.header {\n              height: 15%; }\n  #home_page > section:first-child > section.login > mat-card > section.header > .mat-icon {\n                height: 70px;\n                width: 70px;\n                font-size: 70px; }\n  #home_page > section:first-child > section.login > mat-card > section.body {\n              height: 70%; }\n  #home_page > section:first-child > section.login > mat-card > section.body > form {\n                height: 100%;\n                width: 100%;\n                display: flex;\n                flex-direction: column;\n                justify-content: center; }\n  #home_page > section:first-child > section.login > mat-card > section.body > form .mat-checkbox {\n                  padding-top: 10px; }\n  #home_page > section:first-child > section.login > mat-card > section.body > form .mat-checkbox /deep/.mat-checkbox-label {\n                    color: #eceff1; }\n  #home_page > section:first-child > section.login > mat-card > section.body > form .mat-checkbox /deep/ .mat-checkbox-frame {\n                    border-color: #eceff1; }\n  #home_page > section:first-child > section.login > mat-card > section.body > form /deep/ .mat-form-field input {\n                  color: #eceff1; }\n  #home_page > section:first-child > section.login > mat-card > section.body > form /deep/ .mat-form-field .mat-form-field-label {\n                  color: #eceff1; }\n  #home_page > section:first-child > section.login > mat-card > section.body > form /deep/ .mat-form-field .mat-form-field-underline {\n                  background-color: #eceff1; }\n  #home_page > section:first-child > section.login > mat-card > section.footer {\n              height: 15%; }\n  #home_page > section:first-child > section.login > mat-card > section.footer > button {\n                width: 100%;\n                background: #3b4550;\n                border: 1px solid #eceff1;\n                color: #eceff1; }\n  @media only screen and (max-width: 1024px) {\n            #home_page > section:first-child > section.login > mat-card {\n              margin: 12%;\n              height: 65%; } }\n  @media only screen and (max-width: 1024px) {\n          #home_page > section:first-child > section.login {\n            width: 100%;\n            height: 60%; } }\n  #home_page > section:first-child > section.intro {\n        display: flex;\n        flex-direction: column;\n        justify-content: flex-start;\n        align-items: flex-start;\n        color: #eceff1; }\n  #home_page > section:first-child > section.intro > div, #home_page > section:first-child > section.intro > a {\n          margin-left: 12%;\n          margin-bottom: 0; }\n  #home_page > section:first-child > section.intro > div.logo, #home_page > section:first-child > section.intro > a.logo {\n            height: 120px;\n            width: 160px;\n            background-image: url('liberty-mutual-logo.png');\n            background-size: 160px;\n            background-repeat: no-repeat;\n            background-position: left; }\n  #home_page > section:first-child > section.intro > div.mat-display-2, #home_page > section:first-child > section.intro > a.mat-display-2 {\n            margin-top: 20%;\n            font-size: 35px;\n            text-shadow: 1px 1px 5px #3b4550; }\n  @media only screen and (max-width: 1024px) {\n              #home_page > section:first-child > section.intro > div.mat-display-2, #home_page > section:first-child > section.intro > a.mat-display-2 {\n                margin-top: 5px; } }\n  @media only screen and (max-width: 380px) {\n              #home_page > section:first-child > section.intro > div.mat-display-2, #home_page > section:first-child > section.intro > a.mat-display-2 {\n                font-size: 26px; } }\n  @media only screen and (max-height: 570px) {\n              #home_page > section:first-child > section.intro > div.mat-display-2, #home_page > section:first-child > section.intro > a.mat-display-2 {\n                font-size: 20px;\n                margin-top: -12px; } }\n  #home_page > section:first-child > section.intro > div.mat-display-1, #home_page > section:first-child > section.intro > a.mat-display-1 {\n            padding-left: 4px;\n            font-size: 23px;\n            text-shadow: 1px 1px 5px #3b4550; }\n  @media only screen and (max-width: 380px) {\n              #home_page > section:first-child > section.intro > div.mat-display-1, #home_page > section:first-child > section.intro > a.mat-display-1 {\n                font-size: 18px;\n                line-height: normal;\n                margin-bottom: 6px; } }\n  @media only screen and (max-height: 570px) {\n              #home_page > section:first-child > section.intro > div.mat-display-1, #home_page > section:first-child > section.intro > a.mat-display-1 {\n                font-size: 14px; } }\n  #home_page > section:first-child > section.intro button {\n          border-radius: 25px;\n          margin-left: 12%;\n          margin-top: 5px;\n          font-weight: 600; }\n  #home_page > section:last-child {\n    height: 40px;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    text-align: center;\n    color: #eceff1; }\n"

/***/ }),

/***/ "./src/app/pages/login/login.page.ts":
/*!*******************************************!*\
  !*** ./src/app/pages/login/login.page.ts ***!
  \*******************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../app.service */ "./src/app/app.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ngx_pwa_local_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ngx-pwa/local-storage */ "./node_modules/@ngx-pwa/local-storage/fesm5/ngx-pwa-local-storage.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};




var LoginPage = /** @class */ (function () {
    function LoginPage(appService, router, localStorage) {
        this.appService = appService;
        this.router = router;
        this.localStorage = localStorage;
        this.username = '';
        this.password = '';
        this.rememberMe = true;
        this.myStyle = {};
        this.myParams = {};
        this.width = 100;
        this.height = 100;
        this.credentialsError = false;
        this.isLoggingIn = false;
    }
    LoginPage.prototype.ngOnInit = function () {
        this.myStyle = this.appService.myStyle;
        this.myParams = this.appService.myParams;
        this.width = this.appService.width;
        this.height = this.appService.height;
    };
    LoginPage.prototype.login = function () {
        var _this = this;
        if (!this.username || this.username.length < 1 || !this.password || this.password.length < 1) {
            this.appService.openSnackBar('Empty username/password', 'Ok', true);
        }
        else {
            this.isLoggingIn = true;
            if ((this.username == 'admin' && this.password == 'admin') || (this.username == 'n0349979' && this.password == 'admin')
                || (this.username == 'n0348668' && this.password == 'user')) {
                setTimeout(function () {
                    switch (_this.username) {
                        case 'n0348668':
                            _this.appService.setUser(_this.username, _this.username, 'user');
                            break;
                        default:
                            _this.appService.setUser(_this.username, _this.username, 'admin');
                            break;
                    }
                    if (_this.rememberMe) {
                        _this.localStorage.setItem('lmuser', _this.appService.getUser()).subscribe(function (data) {
                            console.log('Local storage saved!');
                        });
                    }
                    _this.router.navigate(['app']);
                    _this.isLoggingIn = false;
                }, 1000);
            }
            else {
                this.isLoggingIn = false;
                this.appService.openSnackBar('Invalid Credentials', 'Ok', true);
            }
            // this.appService.login(this.username, this.password).subscribe(data => {
            //   //console.log(data);
            //   if(data.group == 'ADMIN'){
            //     this.appService.setUser('n002', this.username, 'admin');          
            //     this.router.navigate(['app']);
            //   }
            //   else {
            //     this.appService.setUser('n003', this.username, 'user');      
            //     this.router.navigate(['app']);
            //   }
            //   if(this.rememberMe) {
            //     this.localStorage.setItem('lmuser',this.appService.getUser()).subscribe(data =>{
            //       console.log('Local storage saved: ' + data);
            //     });
            //   }
            //   this.isLoggingIn = false;        
            // },
            // error => {
            //   this.isLoggingIn = false;
            //   this.appService.openSnackBar('Something Went Wrong!', 'Ok', true); 
            // })
        }
    };
    LoginPage.prototype.knowMore = function () {
        this.appService.aboutAppBehavior.next(true);
    };
    LoginPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/pages/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/pages/login/login.page.scss")]
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _ngx_pwa_local_storage__WEBPACK_IMPORTED_MODULE_3__["LocalStorage"]])
    ], LoginPage);
    return LoginPage;
}());



/***/ }),

/***/ "./src/app/pages/shared/about/about.component.html":
/*!*********************************************************!*\
  !*** ./src/app/pages/shared/about/about.component.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section id=\"about-app\" [ngClass]=\"{ 'open': !!open }\">\n    <button  *ngIf=\"!!open\" mat-icon-button class=\"close-btn\" color=\"accent\" (click)=\"close()\"><mat-icon>close</mat-icon></button>\n\n    <div class=\"header\">\n        <a class=\"logo\" href=\"https://www.libertymutual.com/\" target=\"_blank\"></a>\n    </div>\n\n    <div class=\"about-content\"> \n      <div class=\"feature-row\">\n        <div class=\"info-content\">\n          <div>\n              <h1 class=\"mat-headline\">Cluster Management            \n                  <div class=\"line\"></div>\n              </h1>\n          </div>          \n          <div class=\"mat-body-2\">\n              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n          </div>\n        </div>\n        <div class=\"image-content\">\n          <div class=\"image\">\n            <div class=\"cluster-management\"></div>\n          </div>\n        </div>\n      </div>\n      <div class=\"feature-row\">\n        <div class=\"image-content\">\n            <div class=\"image left\">\n                <div class=\"cluster-creation\"></div>\n            </div>\n        </div>\n        <div class=\"info-content\">\n          <div>\n            <h1 class=\"mat-headline\">Cluster Creation\n              \n              <div class=\"line\"></div>\n            </h1>\n          </div>\n          <div class=\"mat-body-2\">\n              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n          </div>\n        </div>\n      </div>\n      <div class=\"feature-row\">\n        \n          <div class=\"info-content\">\n            <div>\n              <h1 class=\"mat-headline\">Data Management\n                \n                <div class=\"line\"></div>\n              </h1>\n            </div>\n            <div class=\"mat-body-2\">\n                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n            </div>\n          </div>\n          <div class=\"image-content\">\n              <div class=\"image\">\n                  <div class=\"data-management\"></div>\n              </div>\n          </div>\n        </div>\n  \n      <div class=\"feature-row\">\n        <div class=\"image-content\">\n            <div class=\"image left\">\n                <div class=\"user-management\"></div>\n            </div>\n        </div>\n        <div class=\"info-content\">\n          <div>\n            <h1 class=\"mat-headline\">User Management (Admin)\n              \n              <div class=\"line\"></div>\n            </h1>\n          </div>\n          <div class=\"mat-body-2\">\n              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n          </div>\n        </div>\n        \n      </div>\n      <div class=\"feature-row\">\n        <div class=\"info-content\">\n          <div>\n            <h1 class=\"mat-headline\">Cluster Management (Admin)\n              \n              <div class=\"line\"></div>\n            </h1>\n          </div>\n          <div class=\"mat-body-2\">\n              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n          </div>\n        </div>\n        \n        <div class=\"image-content\">\n            <div class=\"image-content\">\n                <div class=\"image\">\n                    <div class=\"cluster-management-admin\"></div>\n                </div>\n            </div>\n        </div>\n      </div>\n      <div class=\"feature-row\">\n        <div class=\"image-content\">\n            <div class=\"image-content\">\n                <div class=\"image left\">\n                    <div class=\"log-management\"></div>\n                </div>\n            </div>\n        </div>\n        <div class=\"info-content\">\n          <div>\n              <h1 class=\"mat-headline\">Logs Management\n            \n                  <div class=\"line\"></div>\n                </h1>\n          </div>\n          \n          <div class=\"mat-body-2\">\n              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\n          </div>\n        </div>\n        \n      </div>\n    </div>\n\n    \n    <particles *ngIf=\"!!open\" [style]=\"myStyle\" [width]=\"width\" [height]=\"height\" [params]=\"myParams\"></particles>\n</section>"

/***/ }),

/***/ "./src/app/pages/shared/about/about.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/shared/about/about.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "#about-app {\n  height: 0%;\n  width: 100%;\n  position: fixed;\n  z-index: 9999;\n  bottom: 0;\n  left: 0;\n  background: linear-gradient(#3b4550, #3b4550, #3b4550, #3b4550, #3b4550, #3b4550, #3b4550, #444e59, #505a66, #65707c);\n  overflow-x: hidden;\n  transition: .3s;\n  box-shadow: 0px -2px 10px #353535; }\n  #about-app.open {\n    height: 100%; }\n  #about-app .header {\n    display: inline-block;\n    width: 55%;\n    height: auto; }\n  @media only screen and (max-width: 1024px) {\n      #about-app .header {\n        width: 100%; } }\n  #about-app .header > a.logo {\n      display: inline-block;\n      height: 120px;\n      width: 160px;\n      margin-left: 12%;\n      background-image: url('liberty-mutual-logo.png');\n      background-size: 160px;\n      background-repeat: no-repeat;\n      background-position: left; }\n  #about-app .about-content {\n    margin: 0 6.6% 30px;\n    width: 87%;\n    min-height: 200px;\n    z-index: 999999;\n    color: #f5f5f5;\n    display: flex;\n    flex-direction: column; }\n  @media only screen and (max-width: 1024px) {\n      #about-app .about-content {\n        margin: 0 12%;\n        width: 76%; } }\n  #about-app .about-content > .feature-row {\n      display: flex;\n      flex-direction: row;\n      padding: 25px 0 25px 0; }\n  #about-app .about-content > .feature-row > .image-content {\n        width: 50%;\n        text-align: center;\n        perspective: 600;\n        -webkit-perspective: 600;\n        z-index: 9999; }\n  #about-app .about-content > .feature-row > .image-content .image {\n          display: inline-block;\n          height: 200px;\n          width: 60%;\n          background: #eceff1;\n          border-radius: 10px;\n          box-shadow: 5px 5px 10px #343434;\n          padding: 20px;\n          perspective: 600;\n          -webkit-perspective: 600;\n          -webkit-transform: rotateY(-35deg);\n                  transform: rotateY(-35deg);\n          -webkit-animation: image-animation 3s ease-in-out;\n          animation: image-animation 3s ease-in-out;\n          transition: -webkit-transform 3s;\n          transition: transform 3s;\n          transition: transform 3s, -webkit-transform 3s; }\n  #about-app .about-content > .feature-row > .image-content .image > div {\n            height: 100%;\n            width: 100%;\n            background-size: contain;\n            background-position: center;\n            background-repeat: no-repeat;\n            -webkit-transform: rotateY(-35deg);\n                    transform: rotateY(-35deg);\n            transition: -webkit-transform 3s;\n            transition: transform 3s;\n            transition: transform 3s, -webkit-transform 3s;\n            -webkit-animation: image-animation 3s ease-in-out;\n            animation: image-animation 3s ease-in-out; }\n  #about-app .about-content > .feature-row > .image-content .image > div.cluster-management {\n              background-image: url('cluster-management.png'); }\n  #about-app .about-content > .feature-row > .image-content .image.left {\n            -webkit-transform: rotateY(35deg);\n                    transform: rotateY(35deg);\n            -webkit-animation: image-animation-2 3s ease-in-out;\n            animation: image-animation-2 3s ease-in-out;\n            box-shadow: -5px 5px 10px #343434; }\n  #about-app .about-content > .feature-row > .image-content .image.left > div {\n              -webkit-transform: rotateY(35deg);\n                      transform: rotateY(35deg);\n              -webkit-animation: image-animation-2 3s ease-in-out;\n              animation: image-animation-2 3s ease-in-out; }\n  #about-app .about-content > .feature-row > .image-content:hover .image {\n          -webkit-transform: rotateY(-25deg);\n                  transform: rotateY(-25deg); }\n  #about-app .about-content > .feature-row > .image-content:hover .image.left {\n            -webkit-transform: rotateY(25deg);\n                    transform: rotateY(25deg); }\n  #about-app .about-content > .feature-row > .info-content {\n        width: 50%;\n        text-align: justify;\n        z-index: 9999;\n        text-shadow: 1px 1px 1px #343434;\n        display: flex;\n        flex-direction: column;\n        justify-content: center; }\n  #about-app .about-content > .feature-row > .info-content h1 {\n          position: relative;\n          display: inline-block;\n          width: auto;\n          text-align: left; }\n  #about-app .about-content > .feature-row > .info-content h1 .line {\n            position: absolute;\n            bottom: -5px;\n            height: 2px;\n            width: 100%;\n            background: #f5f5f5; }\n  @media only screen and (max-width: 1024px) {\n        #about-app .about-content > .feature-row:nth-child(odd) {\n          flex-direction: column; }\n        #about-app .about-content > .feature-row:nth-child(even) {\n          flex-direction: column-reverse; }\n        #about-app .about-content > .feature-row > .image-content, #about-app .about-content > .feature-row > .info-content {\n          width: 100%; }\n        #about-app .about-content > .feature-row > .info-content {\n          padding-bottom: 40px; } }\n  #about-app .close-btn {\n    position: fixed;\n    right: 15px;\n    top: 30px;\n    -webkit-animation: particle-appear 2s;\n            animation: particle-appear 2s; }\n  #about-app .close-btn .mat-icon {\n      font-size: 30px;\n      height: 30px;\n      width: 30px;\n      cursor: pointer; }\n  #about-app /deep/ .particles-container {\n    -webkit-animation: particle-appear 1s;\n            animation: particle-appear 1s; }\n  @keyframes particle-appear {\n  from {\n    opacity: 0;\n    z-index: -1; }\n  to {\n    opacity: 1;\n    z-index: 9999; } }\n  @-webkit-keyframes particle-appear {\n  from {\n    opacity: 0; }\n  to {\n    opacity: 1; } }\n  @keyframes image-animation {\n  from {\n    -webkit-transform: rotateY(-25deg);\n            transform: rotateY(-25deg); }\n  to {\n    -webkit-transform: rotateY(-35deg);\n            transform: rotateY(-35deg); } }\n  @-webkit-keyframes image-animation {\n  from {\n    -webkit-transform: rotateY(-25deg);\n            transform: rotateY(-25deg); }\n  to {\n    -webkit-transform: rotateY(-35deg);\n            transform: rotateY(-35deg); } }\n  @keyframes image-animation-2 {\n  from {\n    -webkit-transform: rotateY(25deg);\n            transform: rotateY(25deg); }\n  to {\n    -webkit-transform: rotateY(35deg);\n            transform: rotateY(35deg); } }\n  @-webkit-keyframes image-animation-2 {\n  from {\n    -webkit-transform: rotateY(25deg);\n            transform: rotateY(25deg); }\n  to {\n    -webkit-transform: rotateY(35deg);\n            transform: rotateY(35deg); } }\n"

/***/ }),

/***/ "./src/app/pages/shared/about/about.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/shared/about/about.component.ts ***!
  \*******************************************************/
/*! exports provided: AboutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutComponent", function() { return AboutComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../app.service */ "./src/app/app.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var AboutComponent = /** @class */ (function () {
    function AboutComponent(appService) {
        this.appService = appService;
        this.open = false;
        this.myStyle = {};
        this.myParams = {};
        this.width = 100;
        this.height = 100;
    }
    AboutComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.myStyle = this.appService.myStyle;
        var params = JSON.parse(JSON.stringify(this.appService.myParams));
        // params.particles.color.value = '#c1c1c1';
        // params.particles.shape.stroke.color = '#c1c1c1';
        // params.particles.line_linked.color = '#c1c1c1';
        // params.particles.line_linked.opacity = 0.6;
        this.myParams = params;
        this.width = this.appService.width;
        this.height = this.appService.height;
        this.appService.aboutAppBehavior.subscribe(function (data) {
            _this.open = data;
        });
    };
    AboutComponent.prototype.close = function () {
        this.appService.aboutAppBehavior.next(false);
    };
    AboutComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-about',
            template: __webpack_require__(/*! ./about.component.html */ "./src/app/pages/shared/about/about.component.html"),
            styles: [__webpack_require__(/*! ./about.component.scss */ "./src/app/pages/shared/about/about.component.scss")]
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]])
    ], AboutComponent);
    return AboutComponent;
}());



/***/ }),

/***/ "./src/app/pages/shared/internet-check/internet-check.component.html":
/*!***************************************************************************!*\
  !*** ./src/app/pages/shared/internet-check/internet-check.component.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"internet-check has-connection mat-caption\" *ngIf=\"hasConnection\">\n  <div>Great! Connected to internet!</div>\n  <button mat-icon-button (click)=\"close()\">&times;</button>\n</div>\n\n<div class=\"internet-check no-connection mat-caption\" *ngIf=\"!hasConnection\">\n  <div>No internet connection!</div>\n  <button mat-icon-button (click)=\"close()\">&times;</button>\n</div>\n"

/***/ }),

/***/ "./src/app/pages/shared/internet-check/internet-check.component.scss":
/*!***************************************************************************!*\
  !*** ./src/app/pages/shared/internet-check/internet-check.component.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".internet-check {\n  height: 48px;\n  width: 262px;\n  position: fixed;\n  bottom: 0;\n  left: 0;\n  font-weight: 500;\n  color: #f1f1f1;\n  background: grey;\n  border-radius: 2px;\n  box-shadow: 0 0 5px #37474f;\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  padding: 0 15px 0 25px;\n  z-index: 9999;\n  margin: 24px;\n  -webkit-animation: slide-in .2s ease-in-out;\n          animation: slide-in .2s ease-in-out; }\n  .internet-check > div {\n    font-size: 14px; }\n  .internet-check > button {\n    font-size: 30px; }\n  .internet-check.has-connection {\n    background: #368636; }\n  .internet-check.no-connection {\n    background: #ff392e; }\n  @media only screen and (max-width: 1024px) {\n    .internet-check {\n      width: calc(100% - 40px);\n      bottom: 0;\n      left: 0;\n      border-radius: 0;\n      margin: 0; } }\n  @keyframes slide-in {\n  from {\n    opacity: 0;\n    -webkit-transform: translateY(100%);\n            transform: translateY(100%); }\n  to {\n    opacity: 1;\n    -webkit-transform: translateY(0%);\n            transform: translateY(0%); } }\n  @-webkit-keyframes slide-in {\n  from {\n    opacity: 0;\n    -webkit-transform: translateY(100%);\n            transform: translateY(100%); }\n  to {\n    opacity: 1;\n    -webkit-transform: translateY(0%);\n            transform: translateY(0%); } }\n"

/***/ }),

/***/ "./src/app/pages/shared/internet-check/internet-check.component.ts":
/*!*************************************************************************!*\
  !*** ./src/app/pages/shared/internet-check/internet-check.component.ts ***!
  \*************************************************************************/
/*! exports provided: InternetCheckComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InternetCheckComponent", function() { return InternetCheckComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../app.service */ "./src/app/app.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var InternetCheckComponent = /** @class */ (function () {
    function InternetCheckComponent(appService) {
        this.appService = appService;
        this.hasConnection = true;
        this.closeToast = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
    }
    InternetCheckComponent.prototype.ngOnChanges = function () {
    };
    InternetCheckComponent.prototype.close = function () {
        this.closeToast.emit(false);
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"])(),
        __metadata("design:type", Boolean)
    ], InternetCheckComponent.prototype, "hasConnection", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"])(),
        __metadata("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"])
    ], InternetCheckComponent.prototype, "closeToast", void 0);
    InternetCheckComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'internet-check',
            template: __webpack_require__(/*! ./internet-check.component.html */ "./src/app/pages/shared/internet-check/internet-check.component.html"),
            styles: [__webpack_require__(/*! ./internet-check.component.scss */ "./src/app/pages/shared/internet-check/internet-check.component.scss")]
        }),
        __metadata("design:paramtypes", [_app_service__WEBPACK_IMPORTED_MODULE_1__["AppService"]])
    ], InternetCheckComponent);
    return InternetCheckComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false,
    // baseUrl: 'http://10.141.29.41:8080'
    baseUrl: 'https://dev-backend.tardis.aws.lmig.com'
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/ec2-user/FinalLMIProd/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map